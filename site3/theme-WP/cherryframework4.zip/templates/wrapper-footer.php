<?php
	cherry_static_area( 'footer-top' );
	cherry_static_area( 'footer-bottom' );
?>