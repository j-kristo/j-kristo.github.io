(function($){

	$(document).ready(function(){

		$('#menu-primary>ul>li>a').each(function(){
	        var $this = $(this),
	            txt = $this.text();
		        $this.html('<div class="txt_menu"><span>'+ txt +'</span></div><div class="txt_menu"><span>'+ txt +'</span></div>');
		});

		//$('.cherry-navigation-arrow').each(function(){
			$('.cherry-navigation-arrow').find('.menu-item-has-children').each(function(){
				_this = $(this),
				_this.find(".txt_menu").append('<div class="arrow_mov"></div>');
			});	
		//});

		//cherry-navigation-arrow


		/*$('.block_3').find('li').each(function(){
 			_this = $(this),
 			_this.append('<div class="block_info"></div>');
 			_this.find("h5").appendTo(_this.find(".block_info"));
 			_this.find(".block_info").append('<div class="helper"></div>');
		});

		$('.team_1').find('li').each(function(){
 			_this = $(this),
 			_this.append('<div class="block_info"></div>');
 			_this.find("h5").appendTo(_this.find(".block_info"));
 			_this.find(".excerpt").appendTo(_this.find(".block_info"));
		});


		$('.related-posts_list').find('.related-posts_item').each(function(){
			_this = $(this),
			_this.append('<div class="block_info"></div>');
			_this.find(">a").appendTo(_this.find(".block_info"));
		});

		$('.comment-reply-link').addClass("btn-primary");*/

		



		/*addEventsFunction();


	 	$(window).resize(
		   function(){
		    if($(window).width()< 767){
		    	$('body').find('section').removeClass('lazy-load-box');
		    	$('body').find('section').removeClass('effect-slideup');
		    	$('body').find('section').removeClass('effect-slidedown');
		    	$('body').find('section').removeClass('effect-slidefromleft');
		    	$('body').find('section').removeClass('effect-slidefromright');
		    	$('body').find('section').removeClass('effect-zoomin');
		    	$('body').find('section').removeClass('effect-zoomout');
		    	$('body').find('section').removeClass('effect-rotate');
		    	$('body').find('section').removeClass('effect-skew');
		    	$('body').find('section').removeClass('effect-fade');
		    }


			$('.item_1').each(function(){
				_this = $(this),
				h_a = _this.find(".block_2").outerHeight();
				_this.css({"height": h_a});
			});
			$('.item_2').each(function(){
				_this = $(this),
				h_a = _this.find(".block_2").outerHeight();
				_this.css({"height": h_a});
			});
			$('.item_3').each(function(){
				_this = $(this),
				h_a = _this.find(".block_2").outerHeight();
				_this.css({"height": h_a});
			});


		   }

		).trigger('resize');
*/


	});


   /* function addEventsFunction(){
		$(document).on('scroll', function() {

			setInterval(function () {

					if ( $("div").hasClass("isStuck") ) {
						$(".menu_bg").addClass('act_1');
					}else{
						$(".menu_bg").removeClass('act_1');
					}
			}, 500);

		}).trigger('scroll');
	}


	more_btnFunction();

	function more_btnFunction(){
		 $('.parallax-slider .btn-primary').each(function(){
	        var $this = $(this),
            txt = $this.text();
	        $this.html('<div><i>'+ txt +'</i></div>');
		});
	}*/

	
 
})(jQuery);